from .kygress import regress

print(regress)
