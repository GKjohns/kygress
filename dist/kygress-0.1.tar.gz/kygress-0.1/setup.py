import setuptools

setuptools.setup(
    name='kygress',
    version='0.1',
    description='A python library for fast and loose regression models',
    url='kylejohnson.ai',
    author='gkjohns',
    install_requires=[],
    author_email='gkjohns@gmail.com',
    packages=setuptools.find_packages(),
    zip_safe=False
)
